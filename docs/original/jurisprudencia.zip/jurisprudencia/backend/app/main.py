"""API de jurisprudência: busca, leitura e organização pessoal."""
import os
from contextlib import asynccontextmanager
from datetime import date
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool
from pydantic import BaseModel

DATABASE_URL = os.environ.get(
    "DATABASE_URL", "postgresql://juris:juris_dev@localhost:5432/jurisprudencia"
)
CONFIG = "pt_unaccent"
LIMITE_CONTAGEM = 10000  # contar milhões de resultados é caro; paramos em 10 mil

pool: ConnectionPool | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global pool
    pool = ConnectionPool(DATABASE_URL, min_size=1, max_size=10, kwargs={"row_factory": dict_row})
    yield
    pool.close()


app = FastAPI(title="Jurisprudência", lifespan=lifespan)


def q(sql: str, params=None, one: bool = False, write: bool = False):
    with pool.connection() as conn:
        cur = conn.execute(sql, params or ())
        if write and cur.description is None:
            return None
        rows = cur.fetchall() if cur.description else []
    if one:
        return rows[0] if rows else None
    return rows


# ---------------------------------------------------------------------
# Busca
# ---------------------------------------------------------------------
@app.get("/api/busca")
def busca(
    q_: str = Query("", alias="q", description="Texto da busca (aceita aspas, OR e -exclusão)"),
    tribunal: Optional[list[str]] = Query(None),
    ramo: Optional[str] = None,
    tipo: Optional[str] = None,
    relator: Optional[str] = None,
    data_ini: Optional[date] = None,
    data_fim: Optional[date] = None,
    status: Optional[str] = None,
    pasta_id: Optional[int] = None,
    tag: Optional[str] = None,
    favoritos: bool = False,
    ordem: str = Query("relevancia", pattern="^(relevancia|data_desc|data_asc)$"),
    pagina: int = Query(1, ge=1),
    por_pagina: int = Query(20, ge=1, le=100),
):
    where, params = ["1=1"], {}
    tem_texto = bool(q_.strip())

    if tem_texto:
        where.append("d.busca @@ websearch_to_tsquery(%(cfg)s::regconfig, %(q)s)")
        params["q"] = q_
    params["cfg"] = CONFIG

    if tribunal:
        where.append("t.sigla = ANY(%(tribunal)s)")
        params["tribunal"] = tribunal
    if ramo:
        where.append("t.ramo = %(ramo)s")
        params["ramo"] = ramo
    if tipo:
        where.append("d.tipo = %(tipo)s::tipo_decisao")
        params["tipo"] = tipo
    if status:
        where.append("d.status = %(status)s::status_vigencia")
        params["status"] = status
    if relator:
        where.append("d.relator ILIKE %(relator)s")
        params["relator"] = f"%{relator}%"
    if data_ini:
        where.append("d.data_julgamento >= %(data_ini)s")
        params["data_ini"] = data_ini
    if data_fim:
        where.append("d.data_julgamento <= %(data_fim)s")
        params["data_fim"] = data_fim
    if pasta_id:
        where.append("EXISTS (SELECT 1 FROM decisao_pasta dp WHERE dp.decisao_id = d.id AND dp.pasta_id = %(pasta_id)s)")
        params["pasta_id"] = pasta_id
    if tag:
        where.append(
            "EXISTS (SELECT 1 FROM decisao_tag dt JOIN tags g ON g.id = dt.tag_id "
            "WHERE dt.decisao_id = d.id AND g.nome = %(tag)s)"
        )
        params["tag"] = tag
    if favoritos:
        where.append("EXISTS (SELECT 1 FROM favoritos f WHERE f.decisao_id = d.id)")

    where_sql = " AND ".join(where)
    from_sql = "FROM decisoes d JOIN tribunais t ON t.id = d.tribunal_id"

    if tem_texto and ordem == "relevancia":
        order_sql = "ORDER BY rank DESC, d.data_julgamento DESC NULLS LAST"
        rank_sql = "ts_rank_cd(d.busca, websearch_to_tsquery(%(cfg)s::regconfig, %(q)s))"
    else:
        rank_sql = "0::real"
        order_sql = (
            "ORDER BY d.data_julgamento ASC NULLS LAST"
            if ordem == "data_asc"
            else "ORDER BY d.data_julgamento DESC NULLS LAST"
        )

    # Contagem limitada
    total_row = q(
        f"SELECT count(*) AS n FROM (SELECT 1 {from_sql} WHERE {where_sql} LIMIT {LIMITE_CONTAGEM + 1}) s",
        params, one=True,
    )
    total = total_row["n"]
    total_truncado = total > LIMITE_CONTAGEM
    if total_truncado:
        total = LIMITE_CONTAGEM

    params["limit"] = por_pagina
    params["offset"] = (pagina - 1) * por_pagina

    # headline só na página final (barato): primeiro pagina, depois destaca
    destaque = (
        "ts_headline(%(cfg)s::regconfig, coalesce(p.ementa,''), websearch_to_tsquery(%(cfg)s::regconfig, %(q)s), "
        "'StartSel=<mark>, StopSel=</mark>, MaxFragments=2, MaxWords=45, MinWords=20')"
        if tem_texto else "left(coalesce(p.ementa,''), 400)"
    )
    sql = f"""
        WITH pagina AS (
            SELECT d.id, d.tipo, d.numero_processo, d.classe, d.relator, d.data_julgamento,
                   d.data_publicacao, d.ementa, d.status, t.sigla AS tribunal,
                   {rank_sql} AS rank
            {from_sql}
            WHERE {where_sql}
            {order_sql}
            LIMIT %(limit)s OFFSET %(offset)s
        )
        SELECT p.id, p.tipo, p.numero_processo, p.classe, p.relator, p.data_julgamento,
               p.data_publicacao, p.status, p.tribunal, p.rank,
               {destaque} AS trecho,
               EXISTS (SELECT 1 FROM favoritos f WHERE f.decisao_id = p.id) AS favorito
        FROM pagina p
        {order_sql.replace('d.', 'p.')}
    """
    itens = q(sql, params)
    return {
        "total": total,
        "total_truncado": total_truncado,
        "pagina": pagina,
        "por_pagina": por_pagina,
        "itens": itens,
    }


# ---------------------------------------------------------------------
# Leitura
# ---------------------------------------------------------------------
@app.get("/api/tribunais")
def tribunais():
    return q("SELECT id, sigla, nome, ramo, uf FROM tribunais ORDER BY ramo, sigla")


@app.get("/api/decisoes/{decisao_id}")
def decisao(decisao_id: int):
    d = q(
        """SELECT d.*, t.sigla AS tribunal, t.nome AS tribunal_nome, oj.nome AS orgao_julgador,
                  EXISTS (SELECT 1 FROM favoritos f WHERE f.decisao_id = d.id) AS favorito
           FROM decisoes d
           JOIN tribunais t ON t.id = d.tribunal_id
           LEFT JOIN orgaos_julgadores oj ON oj.id = d.orgao_julgador_id
           WHERE d.id = %s""",
        (decisao_id,), one=True,
    )
    if not d:
        raise HTTPException(404, "Decisão não encontrada")
    d.pop("busca", None)
    d["anotacoes"] = q("SELECT id, texto, trecho, criada_em FROM anotacoes WHERE decisao_id=%s ORDER BY criada_em", (decisao_id,))
    d["tags"] = q("SELECT g.id, g.nome FROM tags g JOIN decisao_tag dt ON dt.tag_id=g.id WHERE dt.decisao_id=%s ORDER BY g.nome", (decisao_id,))
    d["pastas"] = q("SELECT p.id, p.nome FROM pastas p JOIN decisao_pasta dp ON dp.pasta_id=p.id WHERE dp.decisao_id=%s ORDER BY p.nome", (decisao_id,))
    d["relacoes"] = q(
        """SELECT r.id, r.tipo, r.nota, 'saida' AS direcao, o.id AS outra_id,
                  t.sigla AS tribunal, o.numero_processo, o.classe
           FROM relacoes_decisoes r JOIN decisoes o ON o.id = r.destino_id JOIN tribunais t ON t.id = o.tribunal_id
           WHERE r.origem_id = %(id)s
           UNION ALL
           SELECT r.id, r.tipo, r.nota, 'entrada', o.id, t.sigla, o.numero_processo, o.classe
           FROM relacoes_decisoes r JOIN decisoes o ON o.id = r.origem_id JOIN tribunais t ON t.id = o.tribunal_id
           WHERE r.destino_id = %(id)s""",
        {"id": decisao_id},
    )
    d["historico"] = q("SELECT campo, alterado_em FROM historico_alteracoes WHERE decisao_id=%s ORDER BY alterado_em DESC LIMIT 20", (decisao_id,))
    return d


@app.get("/api/estatisticas")
def estatisticas():
    return {
        "decisoes": q("SELECT reltuples::bigint AS n FROM pg_class WHERE relname='decisoes'", one=True)["n"],
        "por_tribunal": q(
            """SELECT t.sigla, count(*) AS n FROM decisoes d JOIN tribunais t ON t.id=d.tribunal_id
               GROUP BY t.sigla ORDER BY n DESC LIMIT 15"""
        ),
        "ultima_coleta": q("SELECT fonte, finalizada_em, inseridas, atualizadas FROM coletas ORDER BY id DESC LIMIT 5"),
    }


# ---------------------------------------------------------------------
# Organização pessoal
# ---------------------------------------------------------------------
class Nome(BaseModel):
    nome: str
    pai_id: Optional[int] = None


class Texto(BaseModel):
    texto: str
    trecho: Optional[str] = None


class Relacao(BaseModel):
    destino_id: int
    tipo: str
    nota: Optional[str] = None


class StatusIn(BaseModel):
    status: str


class BuscaSalva(BaseModel):
    nome: str
    consulta: str = ""
    filtros: dict = {}


@app.put("/api/decisoes/{decisao_id}/favorito")
def favoritar(decisao_id: int):
    q("INSERT INTO favoritos (decisao_id) VALUES (%s) ON CONFLICT DO NOTHING", (decisao_id,), write=True)
    return {"ok": True}


@app.delete("/api/decisoes/{decisao_id}/favorito")
def desfavoritar(decisao_id: int):
    q("DELETE FROM favoritos WHERE decisao_id=%s", (decisao_id,), write=True)
    return {"ok": True}


@app.put("/api/decisoes/{decisao_id}/status")
def mudar_status(decisao_id: int, body: StatusIn):
    q("UPDATE decisoes SET status=%s::status_vigencia WHERE id=%s", (body.status, decisao_id), write=True)
    return {"ok": True}


@app.get("/api/pastas")
def listar_pastas():
    return q(
        """SELECT p.id, p.nome, p.pai_id, count(dp.decisao_id) AS total
           FROM pastas p LEFT JOIN decisao_pasta dp ON dp.pasta_id = p.id
           GROUP BY p.id ORDER BY p.nome"""
    )


@app.post("/api/pastas")
def criar_pasta(body: Nome):
    return q("INSERT INTO pastas (nome, pai_id) VALUES (%s,%s) RETURNING id, nome, pai_id", (body.nome, body.pai_id))[0]


@app.delete("/api/pastas/{pasta_id}")
def apagar_pasta(pasta_id: int):
    q("DELETE FROM pastas WHERE id=%s", (pasta_id,), write=True)
    return {"ok": True}


@app.put("/api/decisoes/{decisao_id}/pastas/{pasta_id}")
def pasta_add(decisao_id: int, pasta_id: int):
    q("INSERT INTO decisao_pasta VALUES (%s,%s) ON CONFLICT DO NOTHING", (decisao_id, pasta_id), write=True)
    return {"ok": True}


@app.delete("/api/decisoes/{decisao_id}/pastas/{pasta_id}")
def pasta_del(decisao_id: int, pasta_id: int):
    q("DELETE FROM decisao_pasta WHERE decisao_id=%s AND pasta_id=%s", (decisao_id, pasta_id), write=True)
    return {"ok": True}


@app.get("/api/tags")
def listar_tags():
    return q(
        """SELECT g.id, g.nome, count(dt.decisao_id) AS total
           FROM tags g LEFT JOIN decisao_tag dt ON dt.tag_id = g.id
           GROUP BY g.id ORDER BY g.nome"""
    )


@app.put("/api/decisoes/{decisao_id}/tags")
def tag_add(decisao_id: int, body: Nome):
    nome = body.nome.strip().lower()
    if not nome:
        raise HTTPException(400, "Tag vazia")
    tag = q(
        "INSERT INTO tags (nome) VALUES (%s) ON CONFLICT (nome) DO UPDATE SET nome=EXCLUDED.nome RETURNING id, nome",
        (nome,),
    )[0]
    q("INSERT INTO decisao_tag VALUES (%s,%s) ON CONFLICT DO NOTHING", (decisao_id, tag["id"]), write=True)
    return tag


@app.delete("/api/decisoes/{decisao_id}/tags/{tag_id}")
def tag_del(decisao_id: int, tag_id: int):
    q("DELETE FROM decisao_tag WHERE decisao_id=%s AND tag_id=%s", (decisao_id, tag_id), write=True)
    return {"ok": True}


@app.post("/api/decisoes/{decisao_id}/anotacoes")
def anotar(decisao_id: int, body: Texto):
    return q(
        "INSERT INTO anotacoes (decisao_id, texto, trecho) VALUES (%s,%s,%s) RETURNING id, texto, trecho, criada_em",
        (decisao_id, body.texto, body.trecho),
    )[0]


@app.delete("/api/anotacoes/{anotacao_id}")
def apagar_anotacao(anotacao_id: int):
    q("DELETE FROM anotacoes WHERE id=%s", (anotacao_id,), write=True)
    return {"ok": True}


@app.post("/api/decisoes/{decisao_id}/relacoes")
def relacionar(decisao_id: int, body: Relacao):
    q(
        """INSERT INTO relacoes_decisoes (origem_id, destino_id, tipo, nota)
           VALUES (%s,%s,%s::tipo_relacao,%s) ON CONFLICT DO NOTHING""",
        (decisao_id, body.destino_id, body.tipo, body.nota), write=True,
    )
    return {"ok": True}


@app.delete("/api/relacoes/{relacao_id}")
def apagar_relacao(relacao_id: int):
    q("DELETE FROM relacoes_decisoes WHERE id=%s", (relacao_id,), write=True)
    return {"ok": True}


@app.get("/api/buscas-salvas")
def buscas_salvas():
    return q("SELECT id, nome, consulta, filtros FROM buscas_salvas ORDER BY nome")


@app.post("/api/buscas-salvas")
def salvar_busca(body: BuscaSalva):
    return q(
        "INSERT INTO buscas_salvas (nome, consulta, filtros) VALUES (%s,%s,%s) RETURNING id, nome",
        (body.nome, body.consulta, Jsonb(body.filtros)),
    )[0]


@app.delete("/api/buscas-salvas/{busca_id}")
def apagar_busca(busca_id: int):
    q("DELETE FROM buscas_salvas WHERE id=%s", (busca_id,), write=True)
    return {"ok": True}


# ---------------------------------------------------------------------
# Frontend estático
# ---------------------------------------------------------------------
FRONTEND = Path(os.environ.get("FRONTEND_DIR", Path(__file__).resolve().parents[2] / "frontend"))
if not FRONTEND.exists():
    FRONTEND = Path("/app/frontend")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONTEND / "index.html")


if FRONTEND.exists():
    app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
