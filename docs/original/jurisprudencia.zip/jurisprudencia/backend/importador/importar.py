"""Importador genérico de decisões (JSONL ou CSV) para o banco.

Uso:
    python -m importador.importar --arquivo dados/exemplo.jsonl --tribunal STJ --fonte "STJ dados abertos"
    python -m importador.importar --arquivo export.csv --tribunal TJCE --fonte "TJCE portal" \
        --mapa dados/mapa_tjce.json

O arquivo precisa (ou, via --mapa, é traduzido para) ter estes campos:
    fonte_id*, ementa*, numero_processo, classe, relator, orgao_julgador, tipo,
    data_julgamento, data_publicacao, inteiro_teor, tese, fonte_url, legislacao_citada

O que é feito:
  - COPY em massa para tabela temporária (rápido para milhões de linhas)
  - upsert: insere novas, atualiza só quando o hash do conteúdo mudou
  - alterações em ementa/tese ficam no histórico (trigger do banco)
  - registro da coleta na tabela `coletas`
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
from datetime import datetime

import psycopg

DATABASE_URL = os.environ.get(
    "DATABASE_URL", "postgresql://juris:juris_dev@localhost:5432/jurisprudencia"
)
LOTE = 5000

CNJ_RE = re.compile(r"(\d{7})-?(\d{2})\.?(\d{4})\.?(\d)\.?(\d{2})\.?(\d{4})")
TIPOS = {
    "acordao", "decisao_monocratica", "sumula", "sumula_vinculante",
    "repercussao_geral", "recurso_repetitivo", "iac", "irdr", "outro",
}

COLUNAS = [
    "fonte_id", "numero_processo", "numero_cnj", "classe", "relator", "orgao_julgador",
    "tipo", "data_julgamento", "data_publicacao", "ementa", "inteiro_teor", "tese",
    "legislacao_citada", "fonte_url", "hash_conteudo",
]


def parse_data(valor):
    if not valor:
        return None
    valor = str(valor).strip()[:10]
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(valor, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def extrair_cnj(numero):
    if not numero:
        return None
    m = CNJ_RE.search(numero)
    if not m:
        return None
    return "{}-{}.{}.{}.{}.{}".format(*m.groups())


def limpar(texto):
    if texto is None:
        return None
    texto = str(texto).replace("\x00", "").strip()
    return texto or None


def normalizar(bruto: dict, mapa: dict) -> dict | None:
    """Traduz uma linha bruta para o formato do banco. Retorna None se inválida."""
    reg = {campo: bruto.get(origem) for campo, origem in mapa.items()} if mapa else dict(bruto)

    fonte_id = limpar(reg.get("fonte_id"))
    ementa = limpar(reg.get("ementa"))
    inteiro_teor = limpar(reg.get("inteiro_teor"))
    if not fonte_id or not (ementa or inteiro_teor):
        return None

    tipo = (limpar(reg.get("tipo")) or "acordao").lower()
    if tipo not in TIPOS:
        tipo = "outro"

    leg = reg.get("legislacao_citada") or []
    if isinstance(leg, str):
        try:
            leg = json.loads(leg)
        except json.JSONDecodeError:
            leg = [x.strip() for x in leg.split(";") if x.strip()]

    numero = limpar(reg.get("numero_processo"))
    tese = limpar(reg.get("tese"))

    conteudo = "\x1f".join(filter(None, [ementa, tese, inteiro_teor]))
    return {
        "fonte_id": fonte_id,
        "numero_processo": numero,
        "numero_cnj": extrair_cnj(numero),
        "classe": limpar(reg.get("classe")),
        "relator": limpar(reg.get("relator")),
        "orgao_julgador": limpar(reg.get("orgao_julgador")),
        "tipo": tipo,
        "data_julgamento": parse_data(reg.get("data_julgamento")),
        "data_publicacao": parse_data(reg.get("data_publicacao")),
        "ementa": ementa,
        "inteiro_teor": inteiro_teor,
        "tese": tese,
        "legislacao_citada": json.dumps(leg, ensure_ascii=False),
        "fonte_url": limpar(reg.get("fonte_url")),
        "hash_conteudo": hashlib.sha256(conteudo.encode("utf-8")).hexdigest(),
    }


def ler_arquivo(caminho: str):
    if caminho.lower().endswith(".csv"):
        with open(caminho, newline="", encoding="utf-8-sig") as f:
            yield from csv.DictReader(f)
    else:
        with open(caminho, encoding="utf-8") as f:
            for n, linha in enumerate(f, 1):
                linha = linha.strip()
                if not linha:
                    continue
                try:
                    yield json.loads(linha)
                except json.JSONDecodeError:
                    print(f"linha {n}: JSON inválido, ignorada", file=sys.stderr)
                    yield {}


def copiar_lote(conn, registros: list[dict]):
    buf = io.StringIO()
    escritor = csv.writer(buf)
    for r in registros:
        escritor.writerow([r[c] if r[c] is not None else "\\N" for c in COLUNAS])
    buf.seek(0)
    with conn.cursor() as cur:
        cur.execute("TRUNCATE _stage")
        with cur.copy(
            f"COPY _stage ({', '.join(COLUNAS)}) FROM STDIN WITH (FORMAT csv, NULL '\\N')"
        ) as cp:
            cp.write(buf.read())


UPSERT = """
WITH novos_orgaos AS (
    INSERT INTO orgaos_julgadores (tribunal_id, nome)
    SELECT DISTINCT %(trib)s, orgao_julgador FROM _stage WHERE orgao_julgador IS NOT NULL
    ON CONFLICT (tribunal_id, nome) DO NOTHING
),
up AS (
    INSERT INTO decisoes (
        tribunal_id, orgao_julgador_id, tipo, numero_processo, numero_cnj, classe, relator,
        data_julgamento, data_publicacao, ementa, inteiro_teor, tese, legislacao_citada,
        fonte, fonte_id, fonte_url, hash_conteudo
    )
    SELECT %(trib)s, oj.id, s.tipo::tipo_decisao, s.numero_processo, s.numero_cnj, s.classe, s.relator,
           s.data_julgamento::date, s.data_publicacao::date, s.ementa, s.inteiro_teor, s.tese,
           s.legislacao_citada::jsonb, %(fonte)s, s.fonte_id, s.fonte_url, s.hash_conteudo
    FROM _stage s
    LEFT JOIN orgaos_julgadores oj ON oj.tribunal_id = %(trib)s AND oj.nome = s.orgao_julgador
    ON CONFLICT (tribunal_id, fonte_id) DO UPDATE SET
        orgao_julgador_id = EXCLUDED.orgao_julgador_id,
        tipo = EXCLUDED.tipo, numero_processo = EXCLUDED.numero_processo,
        numero_cnj = EXCLUDED.numero_cnj, classe = EXCLUDED.classe, relator = EXCLUDED.relator,
        data_julgamento = EXCLUDED.data_julgamento, data_publicacao = EXCLUDED.data_publicacao,
        ementa = EXCLUDED.ementa, inteiro_teor = EXCLUDED.inteiro_teor, tese = EXCLUDED.tese,
        legislacao_citada = EXCLUDED.legislacao_citada, fonte_url = EXCLUDED.fonte_url,
        hash_conteudo = EXCLUDED.hash_conteudo, coletado_em = now()
    WHERE decisoes.hash_conteudo <> EXCLUDED.hash_conteudo
    RETURNING (xmax = 0) AS inserida
)
SELECT count(*) FILTER (WHERE inserida) AS inseridas,
       count(*) FILTER (WHERE NOT inserida) AS atualizadas
FROM up
"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--arquivo", required=True)
    ap.add_argument("--tribunal", required=True, help="Sigla, ex.: STJ")
    ap.add_argument("--fonte", required=True, help="Nome da origem, ex.: 'STJ dados abertos'")
    ap.add_argument("--mapa", help="JSON {campo_banco: coluna_do_arquivo}")
    args = ap.parse_args()

    mapa = json.load(open(args.mapa, encoding="utf-8")) if args.mapa else None

    with psycopg.connect(DATABASE_URL, autocommit=False) as conn:
        row = conn.execute("SELECT id FROM tribunais WHERE sigla = %s", (args.tribunal,)).fetchone()
        if not row:
            sys.exit(f"Tribunal '{args.tribunal}' não existe em `tribunais`.")
        trib = row[0]

        coleta_id = conn.execute(
            "INSERT INTO coletas (fonte) VALUES (%s) RETURNING id", (args.fonte,)
        ).fetchone()[0]
        conn.execute(
            "CREATE TEMP TABLE _stage (fonte_id text, numero_processo text, numero_cnj text, classe text, "
            "relator text, orgao_julgador text, tipo text, data_julgamento text, data_publicacao text, "
            "ementa text, inteiro_teor text, tese text, legislacao_citada text, fonte_url text, hash_conteudo text)"
        )
        conn.commit()

        ins = atu = ign = err = 0
        lote: list[dict] = []
        vistos: set[str] = set()

        def descarrega():
            nonlocal ins, atu, ign, lote, vistos
            if not lote:
                return
            copiar_lote(conn, lote)
            r = conn.execute(UPSERT, {"trib": trib, "fonte": args.fonte}).fetchone()
            ins += r[0]
            atu += r[1]
            ign += len(lote) - r[0] - r[1]  # já existentes e idênticos
            conn.commit()
            print(f"  ... {ins:,} inseridas, {atu:,} atualizadas, {ign:,} inalteradas, {err:,} erros", flush=True)
            lote, vistos = [], set()

        for bruto in ler_arquivo(args.arquivo):
            reg = normalizar(bruto, mapa) if bruto else None
            if reg is None:
                err += 1
                continue
            if reg["fonte_id"] in vistos:  # duplicata dentro do mesmo lote
                ign += 1
                continue
            vistos.add(reg["fonte_id"])
            lote.append(reg)
            if len(lote) >= LOTE:
                descarrega()
        descarrega()

        conn.execute(
            "UPDATE coletas SET finalizada_em=now(), inseridas=%s, atualizadas=%s, ignoradas=%s, erros=%s WHERE id=%s",
            (ins, atu, ign, err, coleta_id),
        )
        conn.commit()
        # Atualiza estatísticas para o planejador de consultas
        conn.autocommit = True
        conn.execute("ANALYZE decisoes")

    print(f"Concluído: {ins:,} inseridas, {atu:,} atualizadas, {ign:,} inalteradas, {err:,} com erro.")


if __name__ == "__main__":
    main()
